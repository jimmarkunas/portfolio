# PBDS Design Continuity — Reference Source Map

These four images are **approved visual references**, not production slide backgrounds.

They are supplied to Codex so PBDS can preserve proven presentation precedent without requiring a future agent to reconstruct the references from old chats.

| Canonical package file | Pattern | First proven consumer | Original approval source |
|---|---|---|---|
| `hero-centered-signal-field-v1.png` | HERO v1 — Centered Signal Field | PDMA Slide 05 | `slide-05-hero-centered-signal-field/slide-05-hero-approved-reference.png` |
| `brand-reveal-particle-horizon-v1.png` | Brand / Reveal v1 — Particle Horizon Reveal | PDMA Slide 11 | `slide-11-brand-reveal-particle-horizon/slide-11-brand-reveal-approved-reference.png` |
| `translation-traceability-framework-to-requirements-v1.png` | Translation / Traceability v1 | PDMA Slide 12 | approved Slide 12 screenshot |
| `before-after-idea-to-spec-v1.png` | Before / After Transformation v1 | PDMA Slide 13 | approved Slide 13 screenshot |

## Ownership rule

- Figma remains PBDS visual authority where a canonical reusable Figma asset/pattern exists.
- These images are reference evidence / approved precedent.
- Semantic presentation content must remain native/editable.
- These files must not become a second PDMA slide-state registry.
- The PBDS reference manifest should describe reusable pattern precedent, not current PDMA execution status.
