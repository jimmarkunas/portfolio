# PBDS Design Continuity — Codex Package v1

## What to do

1. Open Codex in the writable `jimmarkunas/portfolio` repository workspace.
2. Upload this ZIP to the Codex task, or place/extract it somewhere Codex can read.
3. Paste the contents of `CODEX_PROMPT.md` as the task prompt.
4. Tell Codex to execute through commit + push, not just plan.
5. When it finishes, copy the returned `CHATGPT PBDS PROJECT INSTRUCTION` snippet into the ChatGPT PBDS Project instructions.

## Important

This package is documentation/reference canonization only.

It must not change React/CSS/runtime code or implement animated orbs.
